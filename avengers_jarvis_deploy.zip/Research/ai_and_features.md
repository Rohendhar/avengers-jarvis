# AI Integration Research & Concept Exploration

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT EXPLORATION — NOWHERE NEAR FINAL**  
> All AI integration models, voice recognition options, computer vision features, and bartender chatbot concepts are exploratory brainstorming proposals. Technical feasibility and final feature selection will be evaluated during prototyping.

**Lead**: Ro  
**Objective**: Explore practical, impactful, and academically impressive AI features for the automated drink-dispensing table.

---

## 💡 Potential AI Concepts for the Product

### 1. Smart "Bartender" Conversational AI (LLM Integration)
- **Concept**: Instead of just picking a button like "Drink 1", the user talks or chats:
  - *"I want something fruity and sweet with a citrus kick."*
  - *"Make me something refreshing with low sugar."*
- **Mechanism**:
  - LLM runs locally (Ollama / Llama-3-8B / Small model on Pi / Jetson) or connects to cloud API (Gemini / OpenAI).
  - Given the available ingredients currently plumbed into the table (e.g. Pump 1 = Orange Juice, Pump 2 = Cranberry, Pump 3 = Vodka/Soda, Pump 4 = Lime), the LLM dynamically outputs a JSON recipe payload:
    ```json
    {
      "drink_name": "Sunset Citrus Punch",
      "pumps": {
        "1_orange": 120,
        "2_cranberry": 60,
        "3_soda": 60,
        "4_lime": 15
      },
      "total_volume_ml": 255,
      "dialogue": "Pouring you a fresh Sunset Citrus Punch with extra orange and a hint of lime!"
    }
    ```
- **Feasibility**: High. Demonstrates modern AI function-calling and dynamic recipe creation.

---

### 2. Voice Control & Speech Recognition
- **Concept**: Hands-free drink ordering via voice commands.
- **Implementation Options**:
  - **Option A (Offline / Embedded)**: Whisper.cpp / Vosk / Porcupine on Raspberry Pi. Fast, zero-lag, no internet required.
  - **Option B (Cloud Voice)**: Alexa Skills Kit or Gemini Live API audio streaming. Richer conversational ability, needs WiFi.
- **Risk Mitigation**: Always have a fallback physical touchscreen/button interface in case of background noise during demo day.

---

### 3. Computer Vision for Cup Verification & Spill Prevention
- **Concept**: A small camera (Raspberry Pi Camera Module) pointed at the drop/elevator carriage.
- **Features**:
  - **Cup Detection**: Verifies cup is properly seated before lowering or dispensing liquid (prevents pouring into empty air).
  - **Cup Height & Volume Estimation**: Estimates cup size so pumps don't overflow small glasses.
  - **Fill Level Monitoring**: Real-time fill height tracking to cut off pumps when full.
- **Implementation**: Lightweight YOLOv8-nano or OpenCV contour/color thresholding running at 15-30 FPS.

---

### 4. Smart Inventory & Predictive Maintenance
- **Concept**: AI tracks cumulative dispensed volume per bottle, predicting when a bottle is low or when lines need a sanitize cycle.
- **Display**: Dashboard alerting: *"Pump 2 (Cranberry) will be empty in ~2 drinks"*.

---

## 🛠️ Recommended Staging Plan for Ro
1. **Phase 1 (Core)**: Local rule-based JSON dispenser API + responsive Web/Touchscreen UI.
2. **Phase 2 (AI Recommender)**: Integrate LLM drink generator with current ingredient constraints.
3. **Phase 3 (Voice & Vision)**: Add voice trigger and camera cup check as stretch goals.
