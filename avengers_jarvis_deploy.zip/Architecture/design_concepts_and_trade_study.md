# Design Concepts & Trade Study (Ideation Phase)

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT DOCUMENT — NOWHERE NEAR FINAL**  
> All concepts, trade-off comparisons, feasibility scores, and mechanism alternatives listed here are early brainstorming ideas. No final design decisions have been reached.

---

## 🧭 1. Mechanical Motion Concepts (Cup Handling)

| Concept | Mechanism Description | Pros | Cons / Risks | Feasibility |
| :--- | :--- | :--- | :--- | :---: |
| **Concept A: Vertical Lead Screw Elevator (Current Baseline)** | Stepper motor driving a vertical lead screw / linear guide rail to drop and raise the cup. | Compact footprint, smooth vertical motion, robust positioning. | Slower speed, single cup at a time. | High |
| **Concept B: Rotary Carousel / Revolver Indexer** | Rotating platter underneath table with multiple cup slots and an indexer motor. | High throughput, multiple cups staged, visually entertaining through acrylic. | Larger table footprint, more complex alignment. | Medium |
| **Concept C: Scissor Lift / Pantograph Mechanism** | Servo-actuated scissor linkage lifting cup platform. | Dramatic mechanical presentation through transparent window. | Lower rigidity, higher tolerance slop, potential vibration. | Medium |
| **Concept D: Fixed Surface Gantry (Dispenser moves to Cup)** | Cup stays stationary on table top; an overhead concealed robotic gantry lowers nozzle. | Simplest cup handling (no cup drop), zero spill risk inside table. | Less "magic" reveal than an elevator. | High |

---

## 💧 2. Fluidic & Dispensing Concepts

| Concept | Description | Pros | Cons / Risks |
| :--- | :--- | :--- | :--- |
| **Concept 1: Peristaltic Dosing Pumps** | Self-priming positive displacement pumps squeezing silicone tubing. | **100% Food Safe** (fluid never touches pump), highly precise dosing (ml level), no backflow dripping. | Slower flow rate (~100-300 ml/min), requires higher power 12V. |
| **Concept 2: Gravity Feed + Food-Grade Solenoid Valves** | Overhead/elevated reservoirs draining through computer-controlled pinch/solenoid valves. | Fast dispensing, quiet operation, cheap. | Flow rate varies with liquid height, messy calibration, requires tall reservoir height. |
| **Concept 3: Pressurized Co2 / Air Keg Dispenser** | Beverage bottles pressurized with low-pressure air/CO2, opened via micro-solenoids. | Carbonation preserved (great for beer/soda), ultra-fast pour. | Requires pressure vessels, regulators, overpressure safety relief. |

---

## 📱 3. User Interface & Ordering Concepts

| Concept | Description | Pros | Cons |
| :--- | :--- | :--- | :--- |
| **Option 1: Dynamic Tabletop QR Code (Contactless Web App)** | Scan QR with phone -> Web app loads -> Select & Pay. | Zero hardware cost on table surface, waterproof, scales easily. | Requires smartphone + internet connectivity. |
| **Option 2: Embedded Capacitive Touchscreen (Nextion / Waveshare)** | Flush touchscreen mounted into table surface. | Premium feel, works offline, self-contained. | Spill hazard on screen, higher unit cost. |
| **Option 3: Physical Retro Arcade / Bartender Buttons + LEDs** | Mechanical arcade pushbuttons with NeoPixel ring animations. | Ultra-reliable, satisfying tactile feel, crowd-pleaser demo. | Fixed drink options, less dynamic customization. |
| **Option 4: Voice-Activated AI Bartender (Whisper / Gemini)** | Microphone listening for conversational drink requests. | Cutting-edge AI novelty, accessibility. | Background noise in crowded venues/expo hall. |

---

## 🪑 4. Table Enclosure & Form Factor Concepts

| Concept | Form Factor Description | Best For |
| :--- | :--- | :--- |
| **Form A: Dedicated Coffee Table / Side Table** | Standalone furniture piece with internal reservoir cabinet and clear acrylic viewing window. | Senior Design Expo showcase, home/lounge demo. |
| **Form B: Commercial Taproom High-Top Table** | Tall bar table with lockable bottom cabinet, steel-welded legs, heavy-duty spill tray. | Cincinnati brewery/bar pilot deployment. |
| **Form C: Modular Drop-In Tabletop Insert** | Core mechanism self-contained in a box that drops into a pre-cut hole in any existing table. | Scalable manufacturing, retrofit to existing bar furniture. |

---

## 🎯 Next Steps for Ideation
- [ ] Build quick CAD mockups for Mechanical Concepts A vs B.
- [ ] Bench-test a single Peristaltic Pump vs Gravity Solenoid for flow rate & accuracy.
- [ ] Review tradeoffs as a team before committing to Final Baseline for PDR.
