# System Architecture & Subsystem Breakdown

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT CONCEPT — NOWHERE NEAR FINAL**  
> This architectural breakdown outlines exploratory candidate subsystems for the ideation phase. All mechanisms, fluidic choices, electronics, and software components are rough design drafts subject to change.

---

```mermaid
graph TD
    UI[User Interface: Touchscreen / Voice / Mobile] -->|Drink Selection / Commands| SBC[Central Controller: Raspberry Pi / Host]
    SBC -->|Serial / I2C / SPI| MCU[Real-Time MCU: ESP32 / Arduino]
    
    subgraph Electrical & Control
        MCU --> MD[Stepper / Servo Drivers]
        MCU --> PD[Relay / MOSFET Pump Drivers]
        Sensors[Limit Switches, Ultrasonic / IR Cup Sensor, Load Cell] --> MCU
    end

    subgraph Mechanical Subsystem
        MD --> LeadScrew[Linear Rails / Lead Screw Elevator]
        LeadScrew --> CupCarriage[Cup Drop & Raise Carriage]
    end

    subgraph Fluidic Subsystem
        PD --> Pumps[Food-Grade Peristaltic / Diaphragm Pumps]
        Reservoirs[Liquid Containers] --> Pumps
        Pumps --> DispenseNozzle[Dispensing Manifold / Nozzle]
    end

    subgraph AI Features
        SBC --> Mic[Microphone / Voice Processor]
        SBC --> Cam[Optional: Camera / Cup Vision Sensor]
        SBC --> LLM[Smart Drink Recommender / Conversational AI]
    end
```

---

## 2. Subsystem Breakdown

### 2.1 Subsystem A: Mechanical & Structural
- **Table Frame**: Welded steel/aluminum tubing or hardwood structure designed for stability and furniture aesthetics.
- **Viewing Chamber**: Clear acrylic / polycarbonate side-panel allowing presentation visibility of moving internal mechanisms.
- **Cup Elevator Mechanism**:
  - Linear motion: Linear guide rails + NEMA 17/23 stepper motor with lead screw or GT2 timing belt.
  - End-stop safety: Hardware limit switches (optical or mechanical) at top (pickup) and bottom (dispense) positions.
  - Cup centering: Funnel/carriage design to self-align standard cup sizes during drop and elevator motion.

### 2.2 Subsystem B: Fluidics & Dispensing
- **Pumps**: Food-grade 12V peristaltic pumps (self-priming, fluid never contacts pump motor components) or food-grade diaphragm pumps.
- **Plumbing**: Food-safe silicone / PTFE tubing (1/4" or 3/8" ID) with check valves to prevent backflow and dripping.
- **Manifold**: 3D-printed (food-safe PETG) or machined sanitary dispensing head centering multiple lines above the cup.
- **Sanitation / Purge Cycle**: Automated flush mode with warm water reservoir for line cleaning.

### 2.3 Subsystem C: Electrical & Embedded Controls
- **Power Distribution**:
  - 12V/24V DC Switching Power Supply (Main power for pumps, motors, solenoids).
  - 5V / 3.3V Step-Down Regulators (MCU, Raspberry Pi, sensors, LEDs).
- **Motor & Actuator Drivers**: TMC2209 or A4988 silent stepper drivers; MOSFET / Relay modules for pump control.
- **Sensors**:
  - Cup presence detection (IR beam-break, ultrasonic sensor, or microswitch).
  - Spill / leak sensor tray under the dispensing zone.
  - Liquid level detection in supply bottles (capacitive or float sensors).

### 2.4 Subsystem D: Software, UI & AI Integration
- **Local Embedded Firmware (C++/Arduino/FreeRTOS)**:
  - Finite State Machine (IDLE -> LOWERING -> DISPENSING -> RAISING -> READY).
  - Emergency Stop (E-Stop) and fault handling.
- **High-Level OS & UI (Raspberry Pi / Linux)**:
  - Python / FastAPI backend or Electron / Flutter touchscreen GUI.
  - Bluetooth / Web-based smartphone order companion.
- **AI Integration**:
  - Voice Command Processing (Wake-word + speech-to-intent).
  - Conversational Drink Recommender (LLM-based mood/flavor mixer).
  - Cup Fill Level & Type Detection via OpenCV.
