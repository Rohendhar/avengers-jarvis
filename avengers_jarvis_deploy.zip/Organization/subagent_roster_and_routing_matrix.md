# Subagent Directory & Document Routing Matrix

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT WORKFLOW — NOWHERE NEAR FINAL**  
> Subagent responsibilities and document routing protocols are draft operational guidelines established for early project support and are subject to ongoing refinement by the team.

**Institution**: University of Cincinnati (MECH5051 / EECE5001 Senior Design)  
**Project**: Automated Drink-Dispensing Table  

---

## 🤖 1. Subagent Ecosystem & Team Counterparts

```mermaid
graph TD
    User[Team Lead / Ro: Documentation & AI] --> MasterAgent[Senior Design Master Project Agent]
    
    subgraph Specialized Domain Subagents
        MasterAgent --> EA[engineering_subagent]
        MasterAgent --> BA[budgeting_subagent]
        MasterAgent --> IA[inventory_subagent]
        MasterAgent --> TMA[task_manager_subagent]
        MasterAgent --> FA[funding_and_grants_agent]
        MasterAgent --> RA[project_reminder_agent]
    end

    EA -.->|Collaborates with| RoTeam[Ro & Full Engineering Team]
    BA -.->|Supports| Aron[Aron: Procurement & Budget]
    IA -.->|Supports| Eli[Eli: Inventory & Staging]
    TMA -.->|Supports| Shyam[Shyam: Time & Gantt]
    FA -.->|Supports| AronRo[Aron & Ro: Grants/Venture]
    RA -.->|Notifies| AllTeam[All Team Members]
```

---

## 📋 2. Subagent Roster & Roles

| Subagent Name | Human Lead Counterpart | Domain & Scope | Primary Deliverables |
| :--- | :--- | :--- | :--- |
| **`engineering_subagent`** | **Ro & Team** | Mechanical design, fluidics sizing, circuit schematics, embedded code, CAD models, trade studies. | Calculations, wiring diagrams, state-machine code, PDR/CDR technical sections. |
| **`budgeting_subagent`** | **Aron** | Master budget, expense tracking, receipts, BOM pricing comparisons, purchase requests. | Excel/Sheets budget models, cost variance reports, grant budget justifications. |
| **`inventory_subagent`** | **Eli** | Hardware cataloging, physical parts tracking at Eli's location, datasheets, storage bins. | Inventory tracking sheets, component datasheets, lead-time alerts. |
| **`task_manager_subagent`** | **Shyam** | Milestone scheduling, Gantt charts, sprint backlogs, meeting action items. | Mermaid Gantt charts, deliverable checklists, critical-path tracking. |
| **`funding_and_grants_agent`** | **Aron & Ro** | UC Innovation Challenge, 1819 Venture Lab, Main Street Ventures, Cincinnati startup grants. | 1-Page pitches, grant proposals, pitch deck outlines. |
| **`project_reminder_agent`** | **Ro** | Automated reminders, deadline notifications, team email digests. | Scheduled notifications, HTML email digests via `send_reminder.py`. |

---

## 📥 3. Google Drive Ingestion & Document Routing Matrix

When Google Drive files/folders are linked or imported, they will be classified and routed automatically according to this matrix:

| Document Type / File Pattern | Target Subagent | Destination Folder in Project | Action Required Upon Ingestion |
| :--- | :---: | :--- | :--- |
| **CAD Files (`.step`, `.stl`, `.sldprt`, `.dwg`)** | `engineering_subagent` | `docs/architecture/cad/` | Extract dimensional constraints, evaluate weight/tolerances, update BOM. |
| **Schematics & Pinouts (`.pdf`, `.png`, `.kicad_sch`, `.ino`, `.cpp`)** | `engineering_subagent` | `docs/architecture/electronics/` | Verify voltage rails, document pin mappings, update state machine. |
| **Calculations / Engineering Notes (`.xlsx`, `.m`, `.py`)** | `engineering_subagent` | `docs/architecture/calculations/` | Validate motor torque, fluid flow rates, power budget. |
| **Budget Sheets / Quotes / Receipts (`.xlsx`, `.csv`, `.pdf` receipts)** | `budgeting_subagent` | `docs/budget/` | Extract line items into `procurement_and_funding.md`, track actual spend vs $1,000 cap. |
| **Parts Lists / Packaging Slips / Datasheets (`.pdf`, `.xlsx`)** | `inventory_subagent` | `docs/inventory/` | Log acquired parts into inventory tracker, note storage bin/location, link datasheets. |
| **Meeting Notes / Rubrics / Syllabus / Schedules (`.docx`, `.pdf`, `.gdoc`)** | `task_manager_subagent` | `docs/meetings/` & `docs/timeline/` | Extract new action items, assignees, and update Gantt chart milestone dates. |
| **Grant Guidelines / Innovation Challenge Prompts (`.pdf`, `.docx`)** | `funding_and_grants_agent` | `docs/funding/` | Parse evaluation rubric, draft tailored proposal responses, log deadlines. |
| **General Academic / Team Admin Policies** | Master Agent / Ro | `docs/admin/` | Log in project knowledge base for team-wide compliance. |
