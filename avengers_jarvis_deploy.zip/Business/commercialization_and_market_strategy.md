# Commercialization & Market Strategy: B2B Tabletop Dispenser

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT CONCEPT — NOWHERE NEAR FINAL**  
> All business models, pricing structures, venue lease estimates, and operational workflows described below are speculative concepts explored during early project ideation.

**Project**: Smart Automated Drink-Dispensing Table  
**Target Market**: Cincinnati Craft Breweries, High-Volume Bars, Experiential Hospitality & Event Venues  
**Institution**: University of Cincinnati (MECH5051 / EECE5001)  

---

## 🍺 1. Executive Summary & Value Proposition

In high-volume hospitality environments (such as Cincinnati's booming craft brewery scene in OTR, downtown, and surrounding neighborhoods), long bar lines during peak hours lead to:
1. **Lost Revenue**: Customers abandon beverage orders due to wait times.
2. **Bartender Fatigue**: Staff spend time pouring standard draft/mixer drinks rather than high-margin custom cocktails.
3. **Table Bottlenecks**: Waitstaff are tied up taking drink orders and shuttling single drinks.

### The Solution: The Smart Tabletop Dispenser (Vending / Lease Model)
An automated table that serves as an on-demand, in-table beverage dispenser:
- Customers sit down, scan a **dynamic QR code** on the tabletop with their phone, select their beverage, and pay directly via Apple Pay/Google Pay/Credit Card.
- The table receives the encrypted dispense token from the venue POS/cloud server, verifies a cup is seated, lowers the cup into the table, dispenses the exact volume, and elevates the finished beverage.
- **The "Third-Party Vending" Business Model**: Venues do not need to buy tables upfront; instead, units are placed on a **revenue-share or equipment lease contract**, creating passive recurring income while boosting venue beverage volume.

---

## 📱 2. QR Code & Contactless Ordering Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Customer
    participant Table as Table Surface (QR Code)
    participant WebApp as Mobile Web App (No App Download)
    participant POS as Venue POS / Cloud Backend
    participant TableMCU as Table Controller (ESP32/Pi)

    Customer->>Table: Scans unique Table QR Code
    Table->>WebApp: Loads menu tailored to Table # and age verification
    Customer->>WebApp: Selects drink & completes payment (Apple/Google Pay)
    WebApp->>POS: Verifies age/token & records transaction in POS
    POS->>TableMCU: Sends authorized Dispense Command via WebSocket/MQTT
    TableMCU->>TableMCU: Checks cup presence sensor (Safety Check)
    TableMCU->>TableMCU: Lowers elevator -> Dispenses liquid -> Raises cup
    TableMCU-->>WebApp: Notifies customer: "Drink Ready!"
    TableMCU-->>POS: Confirms dispensed volume & logs inventory reduction
```

---

## 🏙️ 3. Cincinnati Regional Market Fit

Cincinnati has one of the highest densities of craft breweries and entertainment districts in the Midwest:

| Target Category | Example Cincinnati Venues | Why This Fits |
| :--- | :--- | :--- |
| **Craft Breweries & Taprooms** | Rhinegeist (OTR), MadTree (Oakley), Braxton (Covington), 50 West (Columbia Twp), Taft's Ale House | Large seating capacity, high foot traffic, strong tech-forward and craft culture. |
| **Entertainment & Social Bars** | Pins Mechanical Co., 16-Bit Bar+Arcade, Fowling Warehouse, The Banks entertainment strip | Experiential, interactive dining/drinking where novel automated features enhance entertainment. |
| **VIP Lounges & Event Spaces** | Hard Rock Casino VIP, TQL Stadium / Paycor Stadium Suites | High-end hospitality offering private, premium in-booth self-dispensing. |

---

## 💼 4. Business Models for Venues

### Model A: Third-Party Vending Contract (Turnkey Revenue Share)
- **Upfront Cost to Venue**: **$0**.
- **Operation**: We install, maintain, and service the table hardware and fluid lines.
- **Revenue Split**: 15–25% commission to the venue per drink dispensed, remaining revenue covers cost of goods, maintenance, and startup profit.

### Model B: Hardware-as-a-Service (HaaS) / Equipment Lease
- Monthly lease per table (e.g. $150–$300/month/table).
- Venue retains 100% of drink revenue and integrates tables into their own beverage inventory (connected directly to kegs or reservoir lines under floor/table).

---

## ⚖️ 5. Compliance, Safety & Legal Considerations
- **Age Verification & Over-Serving Prevention**:
  - Verification tied to initial ID check at venue door or integrated digital ID scan via mobile app.
  - Hard cap per customer/session (e.g., maximum 2-3 standard drinks per hour per authenticated credit card).
- **Sanitary & Health Regulations (NSF Compliance)**:
  - Food-grade 304/316 stainless steel or NSF-approved silicone lines.
  - Automated daily clean-in-place (CIP) hot-water flush cycle.
- **Safety Interlocks**:
  - Mechanical pinch-point prevention and optical safety sensors around cup elevator.
  - In-table spill drainage channel routed to internal waste reservoir.
