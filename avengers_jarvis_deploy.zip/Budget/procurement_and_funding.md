# Procurement, Budget & Funding Tracker

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT DOCUMENT — NOWHERE NEAR FINAL**  
> All dollar amounts, component pricing, BOM quantities, and vendor estimates are rough ballpark numbers used for initial brainstorming. Actual costs and final BOM selections will be determined during detailed engineering design.

**Leads**: Aron (Procurement & Finance), Eli (Inventory & Parts)  

---

## 💰 1. High-Level Budget Summary

| Category | Estimated Budget ($) | Actual Spent ($) | Notes / Sourcing Strategy |
| :--- | :--- | :--- | :--- |
| **Mechanical & Structural** | $120.00 | $0.00 | Frame steel/alu (Welding lab), Linear rails, Lead screw, Bearings, Fasteners |
| **Fluidics & Plumbing** | $90.00 | $0.00 | 4x 12V Food-Grade Peristaltic Pumps, Silicone Tubing, Check Valves, Fittings |
| **Motors & Drivers** | $60.00 | $0.00 | NEMA 17 Stepper, TMC2209 Drivers, Servos/Solenoids |
| **Electronics & Compute** | $90.00 | $0.00 | Raspberry Pi 4 / Zero 2W, ESP32 / Arduino, 12V Power Supply, Buck Converters, Relays/MOSFETs |
| **Enclosure & Presentation** | $80.00 | $0.00 | Table top materials, Acrylic/Polycarbonate viewing window, 3D filament (PETG/PLA) |
| **Contingency / Spares** | $60.00 | $0.00 | Wire, connectors, breadboards, spare fittings |
| **Total Estimated Initial** | **~$500.00** | **$0.00** | Initial target ~$300, overall cap <$1,000 |

---

## 🏆 2. Funding Opportunities

### Innovation Challenge (UC)
- **Award Potential**: ~$300 per team member (up to ~$1,200 for a 4-person team).
- **Deliverables Required**: Problem statement, design concept, simple milestone plan, bill of materials estimate.
- **Action**: Aron & Team to review submission criteria and apply ASAP.

---

## 📦 3. Bill of Materials (BOM) — Preliminary Staging

| Item # | Description | Qty | Target Vendor / Link | Unit Cost ($) | Total ($) | Status | Location Stored |
| :--- | :--- | :---: | :--- | :---: | :---: | :---: | :--- |
| 1 | 12V Peristaltic Dosing Pumps (Food Grade) | 4 | Amazon / AliExpress | $12.00 | $48.00 | Sourcing | Eli's Lab |
| 2 | Food Grade Silicone Tubing (10ft) | 1 | Amazon | $12.00 | $12.00 | Sourcing | Eli's Lab |
| 3 | Linear Guide Rail + Carriage (MGN12H / 300mm) | 1 | Amazon | $18.00 | $18.00 | Sourcing | Eli's Lab |
| 4 | NEMA 17 Stepper Motor + Lead Screw | 1 | Amazon / StepperOnline | $20.00 | $20.00 | Sourcing | Eli's Lab |
| 5 | ESP32-WROOM Dev Board | 2 | Amazon | $7.00 | $14.00 | Sourcing | Eli's Lab |
| 6 | 12V 10A DC Power Supply | 1 | Amazon | $18.00 | $18.00 | Sourcing | Eli's Lab |
| 7 | 4-Channel MOSFET / Relay Module | 1 | Amazon | $8.00 | $8.00 | Sourcing | Eli's Lab |
| 8 | Optical / Mechanical Limit Switches (3-pack) | 1 | Amazon | $6.00 | $6.00 | Sourcing | Eli's Lab |
| 9 | Acrylic Sheet (Clear, 1/8" or 1/4") | 1 | McMaster / Lowe's | $25.00 | $25.00 | Sourcing | Eli's Lab |
| 10 | PETG Filament Spool (Food-safe parts) | 1 | Amazon / Micro Center | $18.00 | $18.00 | Sourcing | Eli's Lab |
