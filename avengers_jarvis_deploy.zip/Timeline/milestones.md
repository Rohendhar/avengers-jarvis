# Project Timeline & Milestone Tracking

> [!WARNING]
> **PRELIMINARY ESTIMATE / DRAFT TIMELINE — NOWHERE NEAR FINAL**  
> All milestone dates, Gantt durations, and sprint phase allocations are ballpark estimates to guide early planning and will be adjusted as university course dates and design deadlines are officially published.

**Lead**: Shyam (Time Management & Gantt Charts)  
**Semester Timeline**: Fall 2026 – Spring 2027 (Senior Design Cycle)  

---

## 🎯 1. Major Milestone Schedule

```mermaid
gantt
    title Automated Drink-Dispensing Table Roadmap
    dateFormat  YYYY-MM-DD
    section Phase 1: Conceptual & Sourcing
    Kickoff & Requirements Gathering       :done,    des1, 2026-08-27, 2026-09-07
    Innovation Challenge First Meeting    :active,  ic1,  2026-09-02, 1d
    Innovation Challenge Application      :         des2, 2026-09-02, 2026-09-20
    Component Sourcing & Bench Testing    :         des3, 2026-09-10, 2026-10-01
    Preliminary Design Review (PDR)       :milestone, m1, 2026-10-05, 0d

    section Phase 2: Subsystem Prototyping
    CAD Modeling & Frame Design           :         sub1, 2026-10-01, 2026-10-25
    Elevator & Linear Motion Test Rig     :         sub2, 2026-10-15, 2026-11-10
    Pump & Fluid Flow Calibration         :         sub3, 2026-10-20, 2026-11-15
    Critical Design Review (CDR)          :milestone, m2, 2026-11-25, 0d

    section Phase 3: Integration & Table Build
    Frame Fabrication & Welding           :         int1, 2026-11-15, 2026-12-15
    Electronics Packaging & Wiring        :         int2, 2026-12-01, 2027-01-15
    UI & AI Feature Integration           :         int3, 2027-01-10, 2027-02-15

    section Phase 4: Testing, Polish & Expo
    System Validation & Spill Tests       :         tst1, 2027-02-15, 2027-03-15
    Acrylic Polish & Demo Aesthetic       :         tst2, 2027-03-01, 2027-03-30
    Senior Design Expo Presentation       :milestone, m3, 2027-04-15, 0d
```

---

## 📋 2. Sprint Deliverables Checklist

### Milestone 1: PDR & Benchtop Proof-of-Concept (Target: Oct 2026)
- [ ] Requirements document finalized (speed, cup capacity, power draw).
- [ ] Innovation Challenge submission completed.
- [ ] Benchtop test: Single pump dosing calibrated volume (±5% accuracy).
- [ ] Benchtop test: Stepper motor moving carriage vertically with limit switches.

### Milestone 2: CDR & Integrated Alpha Prototype (Target: Dec 2026)
- [ ] Complete SolidWorks/Fusion 360 table CAD model and FEA.
- [ ] Full 4-pump dispensing manifold assembled and tested.
- [ ] Microcontroller state machine handling full sequence (Drop -> Fill -> Raise).
- [ ] Initial web/touchscreen UI operational.

### Milestone 3: Final Expo System & Senior Design Expo (Target: April 2027)
- [ ] Table furniture housing completely assembled with clear viewing acrylic.
- [ ] Integrated AI drink recommendation / voice commands active.
- [ ] Final Capstone Report, Poster, and Video Presentation.
